<?php include('include/header.php');

      include('sections/hero-section.php')?>

  <main id="main">

    <?php
          include('sections/clients-section.php');

          include('sections/about-section.php');

          include('sections/tabs-section.php');

          include('sections/services-section.php');

          //include('sections/portfolio-section.php');

          //include('sections/team-section.php');

          include('sections/contact-section.php');
      ?>


  </main><!-- End #main -->

<?php include('include/footer.php');?>
