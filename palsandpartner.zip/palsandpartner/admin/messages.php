<?php
	include('include/header.php');
	include('php/functions.php');
?>

				<div id="page-wrapper">
					<div class="header">
					  <h1 class="page-header">
					      Messages
					  </h1>
					</div>

					<div id="page-inner">

						<?php include('include/messages.php');?>



						<footer>
					    <p>Copyright Pals and Partners. All Rights Reserved</a></p>
					  </footer>

					</div>
					<!-- /. PAGE INNER  -->

				</div>
			<!-- /. PAGE WRAPPER  -->

<?php include('include/footer.php');?>
