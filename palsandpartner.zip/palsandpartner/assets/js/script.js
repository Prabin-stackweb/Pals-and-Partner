function redirectToIndex(){
  window.location.assign("index.php");
}
