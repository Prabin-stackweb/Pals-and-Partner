function showEditProfile(){
  $("#edit-profile").show();
  $("#profile-tab").hide();
}

function cancelEditProfile(){
  $("#edit-profile").hide();
  $("#profile-tab").show();
}
