<!-- ======= Hero Section ======= -->
<section id="hero" class="d-flex align-items-center">

  <div class="container-fluid" data-aos="zoom-out" data-aos-delay="100">
    <div class="row justify-content-center">
      <div class="col-xl-10">
        <div class="row">
          <div class="col-xl-5">
            <h1>Better cleaning experience with Pals and Partners</h1>
            <h2>We are team of talented cleaners</h2>
            <a href="#about" class="btn-get-started scrollto">Get Started</a>
          </div>
        </div>
      </div>
    </div>
  </div>

</section><!-- End Hero -->
