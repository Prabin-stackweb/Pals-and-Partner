-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 09, 2022 at 12:20 AM
-- Server version: 5.7.39
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stackweb_palsandpartner`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(100) NOT NULL,
  `price` float(11,2) DEFAULT NULL,
  `Address` varchar(40) NOT NULL,
  `details` text NOT NULL,
  `dated` varchar(100) NOT NULL,
  `timing` varchar(100) NOT NULL,
  `status` enum('Unpaid','Pending','In Process','Started','Completed') NOT NULL,
  `assigned_to` int(10) DEFAULT NULL,
  `review` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`id`, `customer_id`, `type`, `category`, `price`, `Address`, `details`, `dated`, `timing`, `status`, `assigned_to`, `review`) VALUES
(53, 49, '2', 'Commercial', 499.00, '42 lancaster street,ingleburn,NSW', 'Please contact 0452082227 for assistance', '2022-09-10', '12:30', 'Completed', 47, 'Great work mate. It was good working with Pals and partner.'),
(54, 49, '3', 'Domestic', 999.00, '232 Railway Parade ,Kograh', 'Please press 34 on the intercome.', '2022-09-25', '14:06', 'Completed', 47, 'good job mate'),
(55, 49, '2', 'office', 499.00, '32 hillcrest avenue, mt druit', 'this is test booking for paypal purpose', '2022-09-24', '12:31', 'Completed', 47, 'good job mate'),
(58, 49, '2', '  nmjn nk', 499.00, 'jhjn', 'jn njnkj', '2022-09-11', '04:46', 'Completed', 47, 'ghhgjhbj'),
(59, 49, '2', 'commercial', 499.00, '79 gardenia avenue', 'Detail cleaning in my offfice', '2022-10-27', '00:00', 'In Process', 37, NULL),
(60, 49, '2', 'office', 499.00, '42 lancaster street,ingleburn', 'detail cleaning', '2022-10-14', '14:00', 'Completed', 47, 'good job mate');

-- --------------------------------------------------------

--
-- Table structure for table `availabilty`
--

CREATE TABLE `availabilty` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `day` enum('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
  `from_time` varchar(100) NOT NULL,
  `to_time` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `availabilty`
--

INSERT INTO `availabilty` (`id`, `staff_id`, `day`, `from_time`, `to_time`) VALUES
(3, 44, 'Tuesday', '9am', '6pm'),
(4, 44, 'Wednesday', '9am', '6pm'),
(5, 44, 'Thursday', '9am', '6pm'),
(6, 44, 'Friday', '9am', '12pm'),
(16, 44, 'Saturday', '10:00 am', '11:00 pm'),
(17, 37, 'Monday', '10AM', '10AM'),
(23, 44, 'Sunday', 'off', 'off'),
(25, 47, 'Monday', '9AM', '5PM'),
(26, 47, 'Tuesday', '9AM', '5PM'),
(27, 47, 'Thursday', '2Pm', '5PM'),
(28, 47, 'Sunday', '12AM', '12PM');

-- --------------------------------------------------------

--
-- Table structure for table `cleaningtype`
--

CREATE TABLE `cleaningtype` (
  `id` int(10) NOT NULL,
  `type` varchar(100) NOT NULL,
  `price` float(11,2) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cleaningtype`
--

INSERT INTO `cleaningtype` (`id`, `type`, `price`, `image`) VALUES
(1, 'Basic Cleaning', 99.00, '1662447394advanced.png'),
(2, 'Advanced', 499.00, '1662447402basic.png'),
(3, 'Premium Cleaning', 999.00, '1662447422Professional.png');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE `message` (
  `id` int(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`id`, `name`, `email`, `subject`, `message`) VALUES
(18, 'test', 'test@gmail.com', 'cleaning enquiry', 'hey how you doin'),
(17, 'demo', 'demo@gmail.com', 'demo', 'demo'),
(16, 'Nilaja Dahal', 'Nilajadahal123@gmail.com', 'about cleaning webite SEO', 'Hey i saw your website having less SEO rank. Please contact us for getting your business in top list in search engines.'),
(15, 'Sampurna Thapa Magar', 'sampurnachyang@gmail.com', 'Complain about cleaner', 'I booked your service couple of days ago for my house cleaning. overall cleaning was good but your cleaner broke my vase.I want refund for this one.'),
(14, 'Adam', 'Adam@stackweb.com.au', 'About your  office cleaning Service', 'Hi, i am looking for office cleaning consisting of 4 suites . Can you send me the detail how does pricing works.Thanks!!'),
(19, 'prabin', 'ytest@test.com', 'test', 'stetshdfgba'),
(20, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', 'huhubuhb', 'hhuuhb'),
(21, 'hbdsahjkskja', 'sbdhjabkb@gnag.com', 'bhjfajb', '`nsbkabkjwk'),
(22, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', 'dvbkha', 'dfbkba');

-- --------------------------------------------------------

--
-- Table structure for table `ordered_products`
--

CREATE TABLE `ordered_products` (
  `id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ordered_products`
--

INSERT INTO `ordered_products` (`id`, `order_id`, `product_id`, `qty`) VALUES
(1, 6, 3, 2),
(2, 6, 4, 1),
(3, 7, 3, 2),
(4, 7, 4, 1),
(5, 8, 1, 1),
(6, 8, 3, 1),
(7, 9, 1, 1),
(8, 9, 3, 1),
(9, 10, 1, 1),
(10, 10, 3, 1),
(11, 11, 1, 1),
(12, 12, 1, 1),
(13, 13, 1, 1),
(14, 14, 1, 1),
(15, 15, 1, 1),
(16, 16, 1, 1),
(17, 16, 3, 1),
(18, 16, 3, 1),
(19, 17, 1, 3),
(20, 18, 6, 1),
(21, 19, 1, 1),
(22, 19, 3, 1),
(23, 20, 3, 1),
(24, 20, 4, 1),
(25, 21, 3, 1),
(26, 21, 4, 1),
(27, 22, 4, 1),
(28, 23, 1, 1),
(29, 24, 1, 1),
(30, 25, 3, 1),
(31, 25, 6, 1),
(32, 26, 1, 1),
(33, 27, 3, 1),
(34, 28, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `dated` varchar(100) NOT NULL,
  `status` enum('Unpaid','Pending') NOT NULL,
  `shipped` enum('No','Yes') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `dated`, `status`, `shipped`) VALUES
(19, 45, '2006', 'Pending', 'Yes'),
(20, 23, '2006', 'Pending', 'Yes'),
(21, 23, '2006', 'Unpaid', 'Yes'),
(22, 46, '2006', 'Pending', 'Yes'),
(23, 48, '2006', 'Unpaid', 'No'),
(24, 49, '2006', 'Pending', 'Yes'),
(25, 49, '2006', 'Pending', 'Yes'),
(26, 49, '2005', 'Pending', 'Yes'),
(27, 49, '2009', 'Pending', 'Yes'),
(28, 49, '2007', 'Pending', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` float(11,2) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `price`, `description`, `image`) VALUES
(1, '80% Alcohol Based Hand Sanitiser Gel', 120.00, 'Looking for sanitiser spray? We have a TGA/WHO hospital grade spray in stock.\r\n\r\nâ–¶ 100% Australian Made (Product SDS & Australian Made Certification); Not tested on animals.\r\n\r\nâ–¶ Min. 80% ethanol based medical grade formula\r\n\r\nâ–¶ Ingredients: Ethanol (80%) v/v, Aqua, Acrylates/c10-30 alkyl acrylate crosspolymer, Aloe barbadensis (Aloe Vera) leaf juice, Lavender essential oil, Triethanolamine\r\n\r\nâ–¶ Kills 99.99% of many common harmful germs and bacteria in as little as 15 seconds\r\n\r\nâ–¶ Rinse free, Fast drying & Non-sticky\r\n\r\nâ–¶ Moisturising formula with aloe vera leaf juice & lavender essential oil\r\n\r\n', '16625864393-1200x1200.png'),
(3, 'Face Mask 3PLY 50 pcs - TGA Certified', 10.50, 'Product Specs:\r\n\r\nMeets EN14683 Rating\r\n\r\nBFE >=95%\r\n\r\nPFE >= 95% @0.1% Micron\r\n\r\nBreathability â€“ Delta P <=49Pa/cm3\r\n\r\nBuilt-in Nose piece Length >=8cm\r\n\r\nType/Size â€“ Type A (ear loop Style)/Medium', '1662586527mmexport1629447927568.jpg'),
(6, 'test with image', 11.00, 'testing with image', '1662448959basic.png');

-- --------------------------------------------------------

--
-- Table structure for table `quote_request`
--

CREATE TABLE `quote_request` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `area` decimal(10,0) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `service` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quote_request`
--

INSERT INTO `quote_request` (`id`, `user_id`, `name`, `email`, `phone`, `area`, `frequency`, `service`) VALUES
(11, 23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082227', '123', 'Fortnightly', 'House Cleaning'),
(10, 23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082227', '456', 'Weekly', 'Office Cleaning'),
(9, 36, 'Dipesh Malla', 'dipeshmalla@gmail.com', '3478484949', '678', 'Weekly', 'Office Cleaning'),
(8, 34, 'Sampurna Thapa', 'sampurnachyang@gmail.com', '0452828329', '567', 'Monthly', 'Commercial Cleaning'),
(7, 35, 'Nilaja Dahal', 'Nilajadahal123@gmail.com', '7478489494', '234', 'Fortnightly', 'House Cleaning'),
(12, 23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082227', '46784', 'Weekly', 'House Cleaning'),
(13, 23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082227', '57', 'Weekly', 'Office Cleaning'),
(14, 40, 'deepesh', 'dipesh@gmail.com', '6377382883', '345', 'Fortnightly', 'House Cleaning'),
(15, 23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082229', '467', 'Fortnightly', 'House Cleaning'),
(16, 49, 'Customer One', 'customerpalsandpartner@stackweb.com.au', '0452082227', '12344', 'Fortnightly', 'House Cleaning'),
(17, 49, 'Test Customer', 'customerpalsandpartner@stackweb.com.au', '0452082227', '1334', 'Weekly', 'Office Cleaning'),
(18, 49, 'Test Customer', 'customerpalsandpartner@stackweb.com.au', '0452082227', '1234', 'Weekly', 'House Cleaning');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` varchar(100) NOT NULL,
  `password` text NOT NULL,
  `type` varchar(10) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `phone`, `address`, `password`, `type`, `status`) VALUES
(46, 'email user', 'admin@stackweb.com.au', '0452082227', 'Butwal', '$2y$10$OYGXcAzeGnCEMkqUXFMurupS.RTUB/Juz5Yn4A8CntKeQ90PoaPWu', 'customer', 'active'),
(23, 'Prabin Bhattarai', 'bhattaraiprabin998@gmail.com', '0452082229', '232 railway parade ,Kogarah,2217', '$2y$10$vhu.7x56RXbwYXcT09kCieClI/xeigi7cNzWTuWmV9q/v6mAGv/Im', 'customer', 'active'),
(24, 'Prabin Bhattarai', 'prabinbhattarai998@gmail.com', '0452082227', '79 gardenia avenue', '$2y$10$JKi5ugNJfrNgc7vbRYODe.6nMUyy0alaG8tlDbIWtoH8TsKhVqQD2', 'admin', 'active'),
(31, 'Might asmit', 'mightasmit99@gmail.com', '0452072228', '232 railway parade', '$2y$10$BdqzzbqpVfkPxS7RDms58ug4hJU3YJiwjTRyaiS6HQlKUGyusy7Sm', 'staff', 'Inactive'),
(32, 'Prabin Bhattarai', 'advance@gmail.com', '0452082227', '79 gardenia avenue', '$2y$10$Axl9RugDiyR8u5WpnX9eEuJWDgpWhlB8cBb3BoMt.Wg.G6/2qEpDW', 'staff', 'active'),
(34, 'Sampurna Thapa', 'sampurnachyang@gmail.com', '0452828329', '229 gildfordd road,guildford', '$2y$10$dWewXY0JeVLXCNdNmaSvxu0fpJ8rNlEqrKAGj1XmPCbGUirtVtU1a', 'customer', 'active'),
(35, 'Mrs Nilaja Dahal', 'Nilajadahal@gmail.com', '045248984939', '222 castlreagh street, sydeny,2000', '$2y$10$pAm4G/hvbuaGVUsYgBN9qOsIknVjSYlxVBDppPBWwWvH6imoliGrq', 'customer', 'active'),
(36, 'Dipesh Malla', 'dipeshmalla@gmail.com', '3478484949', '19 parkes road, kogarah,2217', '$2y$10$rXVFnIyU5CUlRE0Q8ynoEemHim./4ugrN6JvE4llECkNICwcd5VFm', 'customer', 'active'),
(37, 'Denny', 'denny123@gmail.com', '0290282733', '12 everton road,strathfield', '$2y$10$7w3Ipx/VaM4/LLCIrSAOce73FmJusQxE4rVIB66vXq4GuAecKovra', 'staff', 'active'),
(40, 'deepesh malla', 'dipesh@gmail.com', '6377382884', '232 railway parade', '$2y$10$Io0FXe9cLuAeHD7oHsw5o.sTykLPP7lk4XzzPwJ71SuMq09KKA7ZS', 'customer', 'active'),
(42, 'prabin Bhattarai', 'pravi@stackweb.com.au', '0452082227', 'nepal', '$2y$10$gKbc3YCgZFtn5obonPM3.u0UXJ54zzkz1mXWZKCjp02cE6x0Oue8a', 'admin', 'active'),
(43, 'test', 'test@tets.com', '0452082227', 'ktm', '$2y$10$G68DWfBbG6Xezeti6r5DBOHq3o3kVwjyNV7bBmzfGbKPCfyGcZDa.', 'customer', 'active'),
(50, 'Sampurna Thapa Magar', 'adminsam@stackweb.com.au', '0426958498', '46 Robertson St, Kogarah', '$2y$10$FtIZM8TQFWRJGBLpZxc78umLrrkmHxU58rdTtcnBILqtj5rwO/B2y', 'admin', 'active'),
(47, 'Staff One', 'staffpalsandpartner@stackweb.com.au', '0452082227', 'Australia', '$2y$10$SJD4BaXm21EOOUtyj3d/SulU3919SVRzBnZtkx.OY7b8Ndtru6TB2', 'staff', 'active'),
(48, 'Prabin Bhattarai', 'adminpalsandpartner@stackweb.com.au', '0452082227', '232 railway parade,Kogarah', '$2y$10$T.x/ZJVgzw.7Vv0uV4fyhu0hJtntnLgd/Lpcc7SPQfBwI6XN5DwzG', 'admin', 'active'),
(49, 'Test Customer', 'customerpalsandpartner@stackweb.com.au', '0452082227', '79 gardenia avenue,bankstown', '$2y$10$Z2TGLbw/XoVbCge.J3lIjuOJauUCeEOJl9x5jGk3wDmFu1st1yvbK', 'customer', 'active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `assigned_to` (`assigned_to`);

--
-- Indexes for table `availabilty`
--
ALTER TABLE `availabilty`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cleaningtype`
--
ALTER TABLE `cleaningtype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ordered_products`
--
ALTER TABLE `ordered_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quote_request`
--
ALTER TABLE `quote_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `availabilty`
--
ALTER TABLE `availabilty`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `cleaningtype`
--
ALTER TABLE `cleaningtype`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `ordered_products`
--
ALTER TABLE `ordered_products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `quote_request`
--
ALTER TABLE `quote_request`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
